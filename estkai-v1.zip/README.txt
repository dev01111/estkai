eSTKai is open source software, here's how to use it:

First, run the batch file: estkai-setup

It will ask you for an "addons repo". Type in the path to install addons from.

WARNING:
Do not execute eSTKai setup after setting up. It won't work.

From there, use the estkai batch file.

Syntax of command:

estkai [kart/track] [package name]

When you execute the following command, estkai will install the package name from the repo that you listed.

Result:

Installing package [package name] from [repo]...
